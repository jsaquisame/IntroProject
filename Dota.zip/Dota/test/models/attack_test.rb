require 'test_helper'

class AttackTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
