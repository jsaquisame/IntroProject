require 'test_helper'

class BaseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
