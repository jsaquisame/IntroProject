class Skill < ApplicationRecord
end
