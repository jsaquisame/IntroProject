class Stat < ApplicationRecord
end
