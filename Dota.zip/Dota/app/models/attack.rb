class Attack < ApplicationRecord
end
